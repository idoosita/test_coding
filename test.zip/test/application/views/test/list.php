<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<div class="container">
 <button data-toggle="modal" data-target="#myModal" class="btn btn-warning" style="float: right; margin-bottom: 30px; margin-top: 30px">Tambah</button>
  <div class="table-responsive">
  <table class="table table-bordered">
    <thead>
      <tr bgcolor='#F7F7FA'>
        <th><center>Name</center></th>
        <th><center>Work</center></th>
        <th><center>Salary</center></th>
        <th><center>Action</center></th>
      </tr>
    </thead>
    <tbody>
      <?php
      $data_tes = $this->Test_model->tampil_data()->result();
      foreach ($data_tes as $row)
      {
      ?>
      <tr>
        <td><center><?php echo $row->name ?></center></td>
        <td><center><?php echo $row->name_work ?></center></td>
        <td><center><?php echo number_format($row->salary) ?></center></td>
        <td>
          <center>
            <a href="crud/delete"><button class="btn btn-default fas fa-trash" style="color: #FF485A"></button></a>
            <a href="crud/edit"><button class="btn btn-default fas fa-edit" style="color: #00EFD1"></button></a>
          </center>
        </td>
      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
  </div>
</div>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal body -->
      <div class="modal-body">
        <form action="crud/add" method="get" accept-charset="utf-8">
          <label class="form-group">Add Data</label>
        <button type="button" class="close" data-dismiss="modal" style="color: red">&times;</button>
        <div class="form-group">
          <input class="form-control" type="text" placeholder="Name..">
        </div>
        <div class="form-group">
            <select id="work" class="form-control" name="id_work">
              <?php 
              foreach ($this->db->get('work')->result() as $row) {
               ?>
                <option value="<?php echo $row->id ?>"><?php echo $row->name_work ?></option>
              <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <select class="form-control" name="id">
              <?php 
              foreach ($this->db->get('kategori')->result() as $row) {
               ?>
                <option value="<?php echo $row->id ?>"><?php echo $row->salary ?></option>
              <?php } ?>
            </select>
        </div>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-warning">Add</button>
      </div>

    </div>
  </div>
</div>