<?php 
function salary($id){
    $CI =& get_instance();
    $data = $CI->db->get_where('kategori', array('id'=>$id))->row();
    $nama = $data->salary;
    return $nama;
}

function name_work($id){
    $CI =& get_instance();
    $data = $CI->db->get_where('work', array('id_work'=>$id))->row();
    $nama = $data->name_work;
    return $nama;
}
?>